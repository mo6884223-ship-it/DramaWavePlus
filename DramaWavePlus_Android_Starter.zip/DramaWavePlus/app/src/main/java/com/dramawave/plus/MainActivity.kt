package com.dramawave.plus

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF090909)
private val Panel = Color(0xFF191919)
private val Red = Color(0xFFE50914)
private val Muted = Color(0xFFAAAAAA)

data class Show(val title: String, val country: String, val genre: String, val description: String)

private val catalog = listOf(
    Show("نبض القلب", "كوري", "رومانسي", "دراما رومانسية تجريبية. أضف رابط مشاهدة مرخّصاً لتفعيل التشغيل."),
    Show("طريق القمر", "صيني", "تاريخي", "حكاية تاريخية تجريبية. أضف رابط مشاهدة مرخّصاً لتفعيل التشغيل."),
    Show("رسائل الشتاء", "ياباني", "دراما", "قصة اجتماعية تجريبية. أضف رابط مشاهدة مرخّصاً لتفعيل التشغيل."),
    Show("موعد تحت المطر", "كوري", "رومانسي", "عمل تجريبي ضمن واجهة التطبيق."),
    Show("مدينة الأحلام", "صيني", "خيال", "عمل تجريبي ضمن واجهة التطبيق.")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DramaApp() }
    }
}

@Composable
fun DramaApp() {
    var selectedTab by remember { mutableStateOf("الرئيسية") }
    var selectedShow by remember { mutableStateOf<Show?>(null) }
    var query by remember { mutableStateOf("") }
    var favorites by remember { mutableStateOf(setOf<String>()) }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Red,
        onBackground = Color.White, onSurface = Color.White
    )) {
        CompositionLocalProvider(LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
            Surface(Modifier.fillMaxSize(), color = Bg) {
                if (selectedShow != null) {
                    DetailScreen(
                        show = selectedShow!!,
                        isFavorite = favorites.contains(selectedShow!!.title),
                        onBack = { selectedShow = null },
                        onFavorite = {
                            val name = selectedShow!!.title
                            favorites = if (favorites.contains(name)) favorites - name else favorites + name
                        }
                    )
                } else {
                    Column(Modifier.fillMaxSize()) {
                        Header()
                        when (selectedTab) {
                            "البحث" -> SearchScreen(query, { query = it }, catalog.filter {
                                it.title.contains(query, true) || it.country.contains(query, true) || it.genre.contains(query, true)
                            }, { selectedShow = it })
                            "المفضلة" -> ShowList(catalog.filter { favorites.contains(it.title) }, { selectedShow = it })
                            else -> HomeScreen(onOpen = { selectedShow = it })
                        }
                        Spacer(Modifier.weight(1f))
                        NavigationBar(containerColor = Panel, contentColor = Color.White) {
                            listOf("الرئيسية", "البحث", "المفضلة").forEach { tab ->
                                NavigationBarItem(
                                    selected = selectedTab == tab,
                                    onClick = { selectedTab = tab },
                                    icon = {
                                        Icon(
                                            when (tab) {
                                                "البحث" -> Icons.Default.Search
                                                "المفضلة" -> Icons.Default.Favorite
                                                else -> Icons.Default.Home
                                            }, contentDescription = tab
                                        )
                                    },
                                    label = { Text(tab) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Red, selectedTextColor = Red,
                                        indicatorColor = Color(0xFF3A1114), unselectedIconColor = Muted
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Header() {
    Row(
        Modifier.fillMaxWidth().background(Bg).padding(horizontal = 18.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text("DramaWave", color = Red, fontSize = 25.sp, fontWeight = FontWeight.Black)
            Text("PLUS  •  عالم الدراما بين يديك", color = Muted, fontSize = 11.sp)
        }
        Icon(Icons.Default.Movie, contentDescription = null, tint = Red, modifier = Modifier.size(30.dp))
    }
}

@Composable
fun HomeScreen(onOpen: (Show) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(bottom = 12.dp)) {
        item {
            Column(Modifier.padding(18.dp)) {
                Text("أهلاً بك في عالم الدراما", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                Text("اكتشف أعمالاً مجانية ومتاحة للمشاهدة", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(16.dp))
                Box(
                    Modifier.fillMaxWidth().height(158.dp)
                        .background(
                            androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFF551016), Color(0xFF171717))),
                            RoundedCornerShape(18.dp)
                        ).padding(18.dp),
                    contentAlignment = Alignment.BottomStart
                ) {
                    Column {
                        Text("دراما تستحق وقتك", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text("كورية • صينية • يابانية", color = Color.LightGray)
                    }
                }
            }
        }
        item { SectionTitle("الأكثر مشاهدة") }
        item { ShowCarousel(catalog.take(3), onOpen) }
        item { SectionTitle("الدراما الكورية") }
        item { ShowCarousel(catalog.filter { it.country == "كوري" }, onOpen) }
        item { SectionTitle("الدراما الصينية واليابانية") }
        item { ShowCarousel(catalog.filter { it.country != "كوري" }, onOpen) }
        item {
            Text(
                "ملاحظة: هذه نسخة تجريبية ببيانات عرض. أضف مصادر فيديو تملك حق عرضها لتفعيل المشاهدة.",
                color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(20.dp)
            )
        }
    }
}

@Composable
fun SectionTitle(title: String) {
    Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 18.dp, end = 18.dp, top = 10.dp, bottom = 10.dp))
}

@Composable
fun ShowCarousel(shows: List<Show>, onOpen: (Show) -> Unit) {
    LazyRow(contentPadding = PaddingValues(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        items(shows) { show ->
            ShowCard(show, onOpen)
        }
    }
}

@Composable
fun ShowCard(show: Show, onOpen: (Show) -> Unit) {
    Column(
        Modifier.width(138.dp).clickable { onOpen(show) }
    ) {
        Box(
            Modifier.fillMaxWidth().height(174.dp)
                .background(
                    androidx.compose.ui.graphics.Brush.linearGradient(
                        listOf(Color(0xFF5B2028), Color(0xFF242424), Color(0xFF111111))
                    ), RoundedCornerShape(12.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Theaters, contentDescription = null, tint = Color(0xFFDD9AA0), modifier = Modifier.size(42.dp))
        }
        Spacer(Modifier.height(7.dp))
        Text(show.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
        Text("${show.country} • ${show.genre}", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun SearchScreen(query: String, onQuery: (String) -> Unit, results: List<Show>, onOpen: (Show) -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        OutlinedTextField(
            value = query, onValueChange = onQuery, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("ابحث عن مسلسل أو بلد أو تصنيف") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Red, unfocusedBorderColor = Color.DarkGray,
                focusedTextColor = Color.White, unfocusedTextColor = Color.White
            )
        )
        Spacer(Modifier.height(16.dp))
        ShowList(results, onOpen)
    }
}

@Composable
fun ShowList(shows: List<Show>, onOpen: (Show) -> Unit) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(shows) { show ->
            Row(
                Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp))
                    .clickable { onOpen(show) }.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(58.dp).background(Color(0xFF542027), RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Movie, null, tint = Color.White)
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(show.title, color = Color.White, fontWeight = FontWeight.Bold)
                    Text("${show.country} • ${show.genre}", color = Muted, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun DetailScreen(show: Show, isFavorite: Boolean, onBack: () -> Unit, onFavorite: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowForward, "رجوع", tint = Color.White) }
            IconButton(onClick = onFavorite) {
                Icon(if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "المفضلة", tint = Red)
            }
        }
        Box(
            Modifier.fillMaxWidth().height(230.dp).padding(horizontal = 18.dp)
                .background(Color(0xFF3A171C), RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.PlayCircle, null, tint = Color.White, modifier = Modifier.size(68.dp))
        }
        Column(Modifier.padding(20.dp)) {
            Text(show.title, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text("${show.country} • ${show.genre}", color = Red, modifier = Modifier.padding(top = 5.dp))
            Spacer(Modifier.height(12.dp))
            Text(show.description, color = Muted, lineHeight = 22.sp)
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = { },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Red)
            ) {
                Icon(Icons.Default.PlayArrow, null)
                Spacer(Modifier.width(8.dp))
                Text("المشاهدة قريباً")
            }
            Text(
                "سيتم تفعيل المشغّل عند إضافة رابط فيديو مجاني ومرخّص لهذا العمل.",
                color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp)
            )
        }
    }
}
